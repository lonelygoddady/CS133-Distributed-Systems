#ifndef _CONST_H
#define _CONST_H

#define n 2048

#define ni n
#define nj n
#define nk n

#endif

